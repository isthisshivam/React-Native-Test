import * as Actions from './index';
export function getListRequest(obj, onSuccess, onFailure) {
  return {
    type: Actions.GET_LIST_REQUEST,
    payload: {
      obj,
    },
    onSuccess,
    onFailure,
  };
}

export function getListSuccess(userData) {
  return {
    type: Actions.GET_LIST_SUCCESS,
    payload: {
      userData,
    },
  };
}

export function getListFailure(userData) {
  return {
    type: Actions.GET_LIST_FAILURE,
    payload: {
      userData,
    },
  };
}
