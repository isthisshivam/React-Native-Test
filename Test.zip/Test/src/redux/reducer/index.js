import {combineReducers} from 'redux';
// root reducer
const appReducer = combineReducers({
    listReducer: listReducer,
  });
 
  export {appReducer}