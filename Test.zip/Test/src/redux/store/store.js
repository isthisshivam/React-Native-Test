import {createStore, applyMiddleware} from 'redux';
import saga from '../saga/index'
import {combineReducers} from 'redux';

import listReducer from '../reducer/ListReducer';
import createSagaMiddleware from 'redux-saga';


  const sagaMiddleware = createSagaMiddleware();
  
  //store
  const store = createStore(listReducer, applyMiddleware(sagaMiddleware));
  sagaMiddleware.run(saga);
  export {store}