import axios from 'axios'
const URL=`https://datausa.io/api/data?drilldowns=State&measures=Population&year=latest`;
export const getList = async (params) => {
  const response = await axios.get(URL);
  return response.data;
};