import * as ActionType from '../../actions/index';
import {takeLatest, call, put} from 'redux-saga/effects';
import {
 getListFailure,getListSuccess
} from '../../actions/ListActions';

import { getList } from '../../services';


function* workerListModule(data) {
  try {
    const Data = yield call(getList);
    yield put(getListSuccess(Data));
    data.onSuccess(Data);
  } catch (error) {
    yield put(getListFailure());
    data.onFailure(error);
  }
}

export default function* watcherListSaga() {
  yield takeLatest(ActionType.GET_LIST_REQUEST, workerListModule);
}