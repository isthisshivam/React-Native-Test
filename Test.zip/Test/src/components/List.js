import React, {useEffect, useState} from 'react';
import {FlatList, View, Text, StyleSheet} from 'react-native';

const Cards = (props) => {
  const {State,Population} = props?.item;
  // console.log('props',props)

return <View style={{height:80, borderColor:'green',alignItems:'center',flexDirection:"row", borderWidth:1,padding:20}}>
  <Text>{State}</Text>
  <Text>{` - (${Population})`}</Text>
</View>
};

const styles = StyleSheet.create({
    list: {
      flex: 1,
    },
  });
export default Cards;
