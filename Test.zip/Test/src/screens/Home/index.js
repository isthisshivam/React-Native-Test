import React, {useEffect, useState} from 'react';
import {FlatList, View, Text, StyleSheet, TextInput} from 'react-native';
import Cards from '../../components/List';
import {useDispatch, useSelector} from 'react-redux';
import { getListRequest } from '../../redux/actions/ListActions';
import useStyle from './style';
const Home = () => {
  const dispatch  =  useDispatch()
  const [search, setSearch] = useState('')
  const list = useSelector(state => state?.userData);
  const isLoading = useSelector(state => state?.showLoader);
  const [listData,setListData] = useState([])
  const styles = useStyle();
  console.log('list:',list)


    useEffect(() => {
   dispatch(getListRequest({},onSuccess,onFailure))
  }, []);

  const onSuccess=(resolve)=>{
    const {data}  = resolve;
    setListData(data.sort((a, b) => {
      return a.Population - b.Population;
  }))
  }
  const onFailure=(reject)=>{
    console.log('onFailure:' , reject)
  }

  useEffect(()=>{
    if(search)
    if(search.length>2){
      let text = search.toLowerCase()
      let filteredName = listData.filter((item) => {
        return item.State.toLowerCase().match(text)
      })
      setListData(filteredName.sort((a, b) => {
        return b.Population - a.Population;
    }))
     }
     else{
      setListData(list.length>0?list.sort((a, b) => {
        return a.Population - b.Population;
    }):[])
     }
  },[search])

  const keyExtractor = (item, ) => {
    return item?.State?.toString()
  };
 
  return (
   <View style={styles.container}>
    <View style={styles.headingContainer}>
      <Text style={styles.heading_700}>Status:
        <Text style={styles.heading_700}>{isLoading?'Loading...':'Completed'}</Text>
      </Text>
    </View>
    <TextInput
     onChangeText={setSearch} 
     value={search} 
     placeholder='Filter' 
     style={styles.input}>
     </TextInput>
     <FlatList
      data={listData}
      renderItem={({item})=><Cards item={item} />}
      keyExtractor={keyExtractor}
      style={styles.list}
    />
   </View>
  );
};

export default Home;