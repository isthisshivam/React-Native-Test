import { StyleSheet } from 'react-native';
const useStyle = () => {
    return (
        StyleSheet.create({
          container:{flex:1,backgroundColor:"white",padding:30},
          headingContainer: {flexDirection:'row', alignItems:'center',height:60},
          heading_700: {color:'green',fontSize:18,},
          input:{height:45, width:150, borderColor:'green', borderWidth:1,paddingHorizontal:20,marginBottom:20}
        })
    )
}
export default useStyle;